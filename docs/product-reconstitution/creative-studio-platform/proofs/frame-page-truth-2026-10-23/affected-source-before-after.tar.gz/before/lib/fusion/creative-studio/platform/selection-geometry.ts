import {
  alignNodes,
  alignNodesToCanvas,
  distributeNodes,
  matchNodeSize,
  tidyNodes,
  type AlignMode,
  type CreativeCompositionBlock,
  type CreativeCompositionNode,
} from "../composition";
import { isLayeredCompositionParent, layeredResizePolicy } from "./layered-region";

export const STUDIO_SELECTION_GEOMETRY_CONTRACT = "studioSelectionGeometry@1.0.0" as const;

export type StudioSelectionGeometryOperation =
  | { kind: "align"; mode: AlignMode }
  | { kind: "align-parent"; mode: AlignMode }
  | { kind: "distribute"; axis: "horizontal" | "vertical" }
  | { kind: "match"; mode: "width" | "height" | "both" }
  | { kind: "tidy" };

export type StudioSelectionCompatibility = {
  compatible: boolean;
  reason: string | null;
  nodes: CreativeCompositionNode[];
  parentId: string | null;
};

export function selectionGeometryCompatibility(
  block: CreativeCompositionBlock,
  ids: readonly string[],
): StudioSelectionCompatibility {
  const requested = new Set(ids);
  const nodes = block.nodes.filter((node) => requested.has(node.id));
  if (nodes.length !== requested.size) return { compatible: false, reason: "Some selected objects are no longer available.", nodes, parentId: null };
  if (nodes.length < 2) return { compatible: false, reason: "Select at least two objects.", nodes, parentId: nodes[0]?.parentId ?? null };
  const parents = new Set(nodes.map((node) => node.parentId ?? null));
  if (parents.size !== 1) return { compatible: false, reason: "Choose sibling objects inside the same Card Surface or Container.", nodes, parentId: null };
  const parentId = nodes[0]?.parentId ?? null;
  if (!isLayeredCompositionParent(block, parentId)) {
    return { compatible: false, reason: "Arrange tools require a Layered Card Surface or Container.", nodes, parentId };
  }
  if (nodes.some((node) => node.locked)) return { compatible: false, reason: "Unlock every selected object before arranging the selection.", nodes, parentId: nodes[0]?.parentId ?? null };
  return { compatible: true, reason: null, nodes, parentId };
}

export function selectionOperationAvailability(
  block: CreativeCompositionBlock,
  ids: readonly string[],
  operation: StudioSelectionGeometryOperation,
): { enabled: boolean; reason: string | null } {
  const base = selectionGeometryCompatibility(block, ids);
  if (!base.compatible) return { enabled: false, reason: base.reason };
  if (operation.kind === "distribute" && base.nodes.length < 3) return { enabled: false, reason: "Distribution needs at least three compatible sibling objects." };
  if (operation.kind === "match") {
    const policies = base.nodes.map(layeredResizePolicy);
    const blocked = operation.mode === "width"
      ? policies.some((policy) => policy === "governed-aspect")
      : operation.mode === "height"
        ? policies.some((policy) => policy !== "free")
        : policies.some((policy) => policy !== "free");
    if (blocked) return { enabled: false, reason: "This size match would violate a selected object’s governed resize policy." };
  }
  return { enabled: true, reason: null };
}

export function applySelectionGeometryOperation(
  block: CreativeCompositionBlock,
  ids: readonly string[],
  operation: StudioSelectionGeometryOperation,
): CreativeCompositionBlock {
  if (!selectionOperationAvailability(block, ids, operation).enabled) return block;
  const selectedIds = [...ids];
  const nodes = operation.kind === "align"
    ? alignNodes(block.nodes, selectedIds, operation.mode)
    : operation.kind === "align-parent"
      ? alignNodesToCanvas(block.nodes, selectedIds, operation.mode)
      : operation.kind === "distribute"
        ? distributeNodes(block.nodes, selectedIds, operation.axis)
        : operation.kind === "match"
          ? matchNodeSize(block.nodes, selectedIds, operation.mode)
          : tidyNodes(block.nodes, selectedIds);
  return nodes === block.nodes ? block : { ...block, nodes };
}

export function selectionOperationHistoryLabel(operation: StudioSelectionGeometryOperation): string {
  if (operation.kind === "align") return `Aligned selection ${operation.mode}`;
  if (operation.kind === "align-parent") return `Aligned selection to parent ${operation.mode}`;
  if (operation.kind === "distribute") return `Distributed selection ${operation.axis}`;
  if (operation.kind === "match") return `Matched selection ${operation.mode}`;
  return "Tidied selection";
}
