import { actionProps, reconcileActionIntent, standardButtonActions, validateActionDestination, type StandardButtonActionIntent } from "@/lib/fusion/card/action-intent-presentation";
import {
  STUDIO_AUTHORING_CAPABILITY_CONTRACT,
  type StudioAuthoringCapabilityContract,
  type StudioAuthoringControl,
  type StudioAuthoringSelectionContext,
} from "../platform/authoring-contract";
import type { StudioCuratedAssemblyMutation, StudioStructuredAssemblyDescriptor } from "../platform/structured-assembly";
import type { StudioSemanticResource } from "../platform/semantic-resource-slot";
import { assertStudioAuthoringCompleteness, declaredAuthoringCapability } from "../platform/authoring-completeness";
import { EVERENCORE_LOVE_AND_THEFT_BLANK_PICK_SOURCE, EVERENCORE_LOVE_AND_THEFT_FAMILY_ID } from "../signature-assets/everencore-love-and-theft";

export const CURATED_AUTHORING_COMMANDS = {
  setLayout: "curated.layout.set",
  setCount: "curated.action-count.set",
  updateAction: "curated.action.update",
  reorderAction: "curated.action.reorder",
  setResourceSlot: "curated.resource-slot.set",
  setAppearance: "curated.appearance.set",
} as const;

export type CuratedAuthoringCommandPayload =
  | { presentationId: string }
  | { count: number }
  | { actionId: string; patch: Extract<StudioCuratedAssemblyMutation, { type: "update-action" }>["patch"] }
  | { controlId: string; slotId: string; resource?: StudioSemanticResource }
  | { controlId: string; roleId: string; value: string }
  | { from: number; to: number };

export function curatedAuthoringSelection(
  assembly: StudioStructuredAssemblyDescriptor,
  selectedNodeId: string,
  activeActionId?: string,
): StudioAuthoringSelectionContext {
  return {
    level: activeActionId ? "module-internal" : "module",
    objectId: selectedNodeId,
    objectKind: "curated-system",
    objectLabel: assembly.familyLabel,
    governance: "curated",
    internalId: activeActionId,
    parentPath: [
      { id: "card", label: "Card", level: "card" },
      { id: assembly.objectId, label: assembly.familyLabel, level: "module" },
    ],
  };
}

export function createCuratedAuthoringCapability(
  assembly: StudioStructuredAssemblyDescriptor,
  activeActionId?: string,
): StudioAuthoringCapabilityContract {
  const active = assembly.slots.find((slot) => slot.id === activeActionId) ?? assembly.slots[0];
  const capabilities=assembly.capabilities??{supportsSublabel:false,supportsSemanticIcon:false,supportsPlug:true,plugOptional:false,plugSide:"derived" as const,supportsBackgroundReflection:false};
  const plugActive=capabilities.supportsPlug&&active?.plugEnabled!==false;
  const compatibleSemanticIcons=assembly.compatibleSemanticIcons??[];
  const actionOptions = standardButtonActions();
  const activePresentation = actionOptions.find((action) => action.kind === active?.actionType) ?? actionOptions.find((action) => action.kind === "website")!;
  const activeSize = assembly.textSizes.find((size) => size.id === (active?.textSize || "medium")) ?? assembly.textSizes.find((size) => size.id === "medium");
  const availableTextSizes = assembly.textSizes.filter((size) => size.availability !== "disabled");
  const precision = assembly.textPrecision;
  const activePx = active?.textSizePx ?? precision?.defaultPx ?? activeSize?.phonePx ?? 14;
  const characterLimit = precision ? characterLimitAt(precision, activePx) : activeSize?.recommendedCharacterCount;
  const precisionSafeMax = precision ? safeMaxForLabel(precision, active?.label.trim().length ?? 0) : undefined;
  const textSizeControls: StudioAuthoringControl[] = precision || availableTextSizes.length > 1 ? [{
    id: "text-size",
    label: "Text size",
    description: "Label size in local CSS pixels. Whole-module placement and certified size limits remain authoritative.",
    type: "precision",
    value: activePx,
    unit: "px",
    min: precision?.minPx ?? Math.min(...availableTextSizes.map((size) => size.phonePx)),
    max: precisionSafeMax ?? Math.max(...availableTextSizes.filter((size) => (active?.label.trim().length ?? 0) <= size.recommendedCharacterCount).map((size) => size.phonePx), Math.min(...availableTextSizes.map((size) => size.phonePx))),
    step: precision?.stepPx ?? 1,
    fineStep: precision?.stepPx ?? .5,
    defaultValue: precision?.defaultPx ?? availableTextSizes.find((size) => size.id === "medium")?.phonePx ?? availableTextSizes[0]?.phonePx ?? 14,
    commandId: CURATED_AUTHORING_COMMANDS.updateAction,
    guidance: "Certified range at phone density.",
  }] : [];
  const roster = {
    id: "action-roster",
    label: "Action roster",
    type: "action-roster" as const,
    commandId: CURATED_AUTHORING_COMMANDS.reorderAction,
    activeId: activeActionId,
    items: assembly.slots.map((slot) => ({ id: slot.id, label: slot.label, secondary: slot.plugLabel || "Compatible plug", previewRef: slot.plugPreviewSrc })),
  };
  const treatmentRoles = assembly.appearance.textTreatmentLabel ? [{
    id: "text-treatment",
    label: "Text treatment",
    optionLabel: assembly.appearance.textTreatmentLabel,
    preview: "linear-gradient(145deg,#fff7d2,#a98445)",
    governed: true,
  }] : [];
  const fixedTextSizeRoles = !precision && availableTextSizes.length === 1 ? [{
    id: "label-size",
    label: "Label size",
    optionLabel: `${availableTextSizes[0].phonePx}px at phone density`,
    preview: "linear-gradient(145deg,#131922,#05070a)",
    governed: true,
  }] : [];
  const resourceControls: StudioAuthoringControl[] = (assembly.resourceSlots ?? [])
    .filter((slot) => slot.applicable)
    .map((slot) => ({
      id: `resource-slot:${slot.id}`,
      label: slot.label,
      description: slot.presentation.ownership === "governed"
        ? "Choose the content. The certified recipe owns its fit and placement."
        : "Choose the content for this surface.",
      type: "asset-slot" as const,
      slot,
      commandId: CURATED_AUTHORING_COMMANDS.setResourceSlot,
      interactionClass: "choice" as const,
      semanticGroup: "content" as const,
      responsivePresentation: "full-browser" as const,
    }));
  const identitySlot = (assembly.resourceSlots ?? []).find((slot) => slot.id === "identity");
  const configurableAppearanceControls: StudioAuthoringControl[] = assembly.appearance.roles
    .filter((role) => !role.governed && role.options.some((option) => option.availability === "enabled"))
    .map((role) => ({
      id: `appearance:${role.id}`,
      label: role.label,
      description: "Choose a Product Owner and Design-certified family treatment.",
      type: "visual-grid" as const,
      value: role.value,
      commandId: CURATED_AUTHORING_COMMANDS.setAppearance,
      interactionClass: "choice" as const,
      semanticGroup: "appearance" as const,
      options: role.options.map((option) => ({
        id: option.id,
        label: option.label,
        previewRef: option.preview,
        availability: option.availability,
        disabledReason: option.disabledReason,
        recommended: option.recommended,
        metadata: { rendererValue: option.rendererValue, roleId: role.id },
      })),
    }));
  const actionAppearanceControls: StudioAuthoringControl[] = active && (assembly.layoutMode === "single-stack" || assembly.layoutMode === "twin-rail")
    ? assembly.appearance.roles
      .filter((role) => !role.governed && role.options.some((option) => option.availability === "enabled"))
      .map((role) => ({
        id: `action-appearance:${role.id}`,
        label: `${role.label} · this action`,
        description: "Override only this action, or return it to the assembly default.",
        type: "visual-grid" as const,
        value: active.appearanceOptionIds?.[role.id] ?? "__inherit__",
        commandId: CURATED_AUTHORING_COMMANDS.updateAction,
        interactionClass: "choice" as const,
        semanticGroup: "appearance" as const,
        options: [
          { id: "__inherit__", label: `Use assembly default · ${role.optionLabel}`, previewRef: role.preview, availability: "enabled" as const, metadata: { roleId: role.id, inherited: true } },
          ...role.options.map((option) => ({ id: option.id, label: option.label, previewRef: option.preview, availability: option.availability, disabledReason: option.disabledReason, recommended: option.recommended, metadata: { rendererValue: option.rendererValue, roleId: role.id } })),
        ],
      }))
    : [];
  const declarations = [
    declaredAuthoringCapability({
      id: "curated.identity",
      label: identitySlot?.label ?? "Curated identity",
      classification: "editable-reachable",
      applicable: Boolean(identitySlot?.applicable),
      stateAuthority: assembly.adapterAuthority,
      compilerAuthority: assembly.compiler,
      rendererAuthority: "SignatureMasterBridge/canonical-composition-renderer",
      persistenceAuthority: "signatureAssemblyAuthoring@1.0.0",
      validationAuthority: "studioSemanticResourceSlot@1.0.0 + Curated recipe socket",
      historyAuthority: "CardBuilder labeled undo/redo",
      controlId: identitySlot ? `resource-slot:${identitySlot.id}` : undefined,
      commandId: CURATED_AUTHORING_COMMANDS.setResourceSlot,
      parityAuthorities: ["canvas", "preview", "public", "live-device"],
      visualAcceptance: identitySlot?.presentation.visualFit ? {
        fitContractId: identitySlot.presentation.visualFit.contractId,
        rendererMapping: "StudioVisualResourceProjection",
        normalResourcePolicy: "host-confirmed-crop",
        incompatibleResourcePolicy: identitySlot.presentation.visualFit.fallback === "reject" ? "reject-with-guidance" : "safe-fallback",
        runtimeInspectionRequired: true,
      } : undefined,
    }),
    declaredAuthoringCapability({
      id: "curated.structural-geometry",
      label: "Curated structural geometry",
      classification: "governed",
      applicable: true,
      stateAuthority: assembly.adapterAuthority,
      compilerAuthority: assembly.compiler,
      rendererAuthority: "SignatureMasterBridge/canonical-composition-renderer",
      persistenceAuthority: "recipe identity and canonical inputs",
      validationAuthority: "certified recipe",
      historyAuthority: "derived output is not directly mutable",
      parityAuthorities: ["canvas", "preview", "public", "live-device"],
    }),
    declaredAuthoringCapability({
      id: "curated.appearance",
      label: "Curated family appearance",
      classification: configurableAppearanceControls.length ? "editable-reachable" : "governed",
      applicable: true,
      stateAuthority: `${assembly.appearance.contractId}@${assembly.appearance.contractVersion}`,
      compilerAuthority: assembly.compiler,
      rendererAuthority: "familyAppearance renderer mappings + canonical composition renderer",
      persistenceAuthority: "signatureAssemblyAuthoring.appearance.semanticOptionIds",
      validationAuthority: "certified family combinations and accessibility rules",
      historyAuthority: "CardBuilder labeled undo/redo",
      controlId: configurableAppearanceControls[0]?.id,
      commandId: configurableAppearanceControls.length ? CURATED_AUTHORING_COMMANDS.setAppearance : undefined,
      parityAuthorities: ["canvas", "preview", "public", "live-device"],
    }),
  ];
  const contract: StudioAuthoringCapabilityContract = {
    contractId: STUDIO_AUTHORING_CAPABILITY_CONTRACT,
    id: `signatureCuratedAuthoring:${assembly.familyId}@1.0.0`,
    version: "1.0.0",
    adapterAuthority: assembly.adapterAuthority,
    subject: { kind: "curated-system", familyId: assembly.familyId },
    selectionLevels: ["module", "module-internal"],
    groups: [
      {
        id: "composition",
        label: "Composition",
        level: "module",
        controls: [
          ...resourceControls,
          {
            id: "layout",
            label: "Layout",
            description: "Choose a certified recipe. Structure recompiles automatically.",
            type: "visual-layout",
            value: assembly.presentationId??assembly.recipeId,
            commandId: CURATED_AUTHORING_COMMANDS.setLayout,
            options: assembly.layouts.map((layout) => ({ id: layout.id, label: layout.density ? `${layout.density.mode[0].toUpperCase()}${layout.density.mode.slice(1)} · ${layout.label}` : layout.label, description: layout.description, availability: "enabled" as const, metadata: { layoutMode:layout.layoutMode??assembly.layoutMode, densityMode:layout.density?.mode??"governed", actionCountOptions: layout.allowedActionCounts.join(",") } })),
          },
          {
            id: "action-count",
            label: "Actions",
            description: "Count remains inside this recipe’s certified limits.",
            type: "count-stepper",
            value: assembly.inputCount,
            options: assembly.allowedActionCounts,
            commandId: CURATED_AUTHORING_COMMANDS.setCount,
          },
          roster,
          ...configurableAppearanceControls,
          {
            id: "appearance",
            label: "Appearance",
            description: "Only Product Owner and Design-certified options are exposed.",
            type: "appearance-status",
            roles: [...assembly.appearance.roles.filter((role) => role.governed), ...treatmentRoles, ...fixedTextSizeRoles],
          },
          {
            id: "governance",
            label: "Governed assembly",
            type: "governance-status",
            statements: ["Attachment geometry and vertical optical alignment remain automatic.", "Rails, bridges, spine, caps, crown, and topper are compiler-owned."],
          },
        ],
      },
      {
        id: "action-navigation",
        label: "Actions",
        level: "module-internal",
        controls: [roster],
      },
      {
        id: "content",
        label: "Content",
        level: "module-internal",
        controls: active ? [
          { id: "label", label: "Label", type: "text", value: active.label, maxLength: characterLimit, guidance: characterLimit ? `${activePx}px is phone-safe up to ${characterLimit} characters in ${assembly.recipeLabel}.` : undefined, commandId: CURATED_AUTHORING_COMMANDS.updateAction },
          ...(capabilities.supportsSublabel?[{ id: "sublabel", label: "Sublabel", type: "text" as const, value: active.sublabel || "", guidance: "Optional secondary copy; phone-safe overflow is truncated by the canonical renderer.", commandId: CURATED_AUTHORING_COMMANDS.updateAction }]:[]),
          { id: "accessible-name", label: "Accessible name", type: "text", value: active.accessibleName || active.label, commandId: CURATED_AUTHORING_COMMANDS.updateAction },
          ...(capabilities.supportsSemanticIcon&&plugActive?[{ id: "semantic-label", label: "Icon accessible label", type: "text" as const, value: active.semanticLabel || active.semanticIconRef?.accessibleLabel || "", commandId: CURATED_AUTHORING_COMMANDS.updateAction }]:[]),
          {
            id: "action-intent",
            label: "Action",
            type: "action-intent",
            value: active.actionType || "website",
            commandId: CURATED_AUTHORING_COMMANDS.updateAction,
            options: actionOptions.map((action) => ({ id: action.kind, label: action.label, availability: "enabled" as const, description: action.fieldLabel, metadata: { inputMode: action.inputMode, placeholder: action.placeholder } })),
          },
          { id: "destination", label: activePresentation.fieldLabel, type: "action-destination", value: active.destination || "", actionType: activePresentation.kind, inputMode: activePresentation.inputMode, placeholder: activePresentation.placeholder, commandId: CURATED_AUTHORING_COMMANDS.updateAction },
          {
            id: "alignment",
            label: "Alignment",
            type: "segmented",
            value: active.textAlign || "center",
            commandId: CURATED_AUTHORING_COMMANDS.updateAction,
            options: ["left", "center", "right"].map((id) => ({ id, label: id[0].toUpperCase() + id.slice(1), availability: "enabled" as const })),
          },
          ...textSizeControls,
          ...actionAppearanceControls,
          ...(capabilities.supportsBackgroundReflection&&capabilities.backgroundReflectionRange?[{
            id:"background-reflection",
            label:"Background reflection",
            description:"Lift or quiet the fan silhouette without changing the selected glass master.",
            type:"precision" as const,
            value:active.backgroundReflectionIntensity??capabilities.backgroundReflectionRange.defaultValue,
            unit:"%" as const,
            min:capabilities.backgroundReflectionRange.min,
            max:capabilities.backgroundReflectionRange.max,
            step:5,
            fineStep:1,
            defaultValue:capabilities.backgroundReflectionRange.defaultValue,
            commandId:CURATED_AUTHORING_COMMANDS.updateAction,
            guidance:"The certified range preserves live-label contrast at phone scale.",
          }]:[]),
          ...(capabilities.plugOptional?[{
            id:"plug-mode",
            label:"Signature plug",
            description:"Reserve the collectible guitar pick for actions that need emphasis.",
            type:"segmented" as const,
            value:active.plugEnabled===false?"body-only":capabilities.plugSide==="authorable"?(active.plugSide??capabilities.allowedPlugSides?.[0]??"left"):"plug",
            commandId:CURATED_AUTHORING_COMMANDS.updateAction,
            options:[
              {id:"body-only",label:"Body",availability:"enabled" as const},
              ...(capabilities.plugSide==="authorable"
                ? (capabilities.allowedPlugSides??["left","right"]).map((id)=>({id,label:`Pick ${id[0].toUpperCase()+id.slice(1)}`,availability:"enabled" as const}))
                : [{id:"plug",label:"Pick",availability:"enabled" as const}]),
            ],
          }]:[]),
          ...(plugActive?[{
            id: "plug",
            label: capabilities.supportsSemanticIcon ? "Plug presentation" : "Compatible plug",
            description: "Only certified socket-compatible choices appear.",
            type: "visual-grid" as const,
            value: active.plugPresentationId ?? active.plugComponentId,
            commandId: CURATED_AUTHORING_COMMANDS.updateAction,
            searchable: true,
            initialVisibleCount: 8,
            options: assembly.compatiblePlugs.map((plug) => ({ id: plug.componentId, label: plug.label, previewRef: plug.previewSrc, availability: "enabled" as const, compatibilityTags: [assembly.recipeId] })),
          }]:[]),
          ...(capabilities.supportsSemanticIcon&&plugActive?[{
            id:"semantic-icon",label:assembly.familyId===EVERENCORE_LOVE_AND_THEFT_FAMILY_ID?"Icon / Insert · Love & Theft Pick Library":"Icon / Insert",description:assembly.familyId===EVERENCORE_LOVE_AND_THEFT_FAMILY_ID?"Choose an exact certified PNG master by meaning or category. Missing semantics remain on the certified blank; Studio does not synthesize pick artwork.":"Choose an approved semantic insert.",type:"visual-grid" as const,value:active.semanticIconRef?.canonicalId??"__blank__",commandId:CURATED_AUTHORING_COMMANDS.updateAction,searchable:true,initialVisibleCount:8,
            options:[{id:"__blank__",label:"Blank / Custom",previewRef:assembly.familyId===EVERENCORE_LOVE_AND_THEFT_FAMILY_ID?EVERENCORE_LOVE_AND_THEFT_BLANK_PICK_SOURCE:undefined,availability:"enabled" as const,metadata:{category:"Love & Theft",sourceAuthority:"certified-master"}},...compatibleSemanticIcons.map((icon)=>({id:icon.canonicalId,label:icon.accessibleLabel??icon.iconName,description:icon.catalogCategory?`${icon.catalogCategory} · Certified source master`:undefined,previewRef:icon.rasterMasterSource??icon.body,availability:"enabled" as const,compatibilityTags:icon.compatibility,metadata:{category:icon.catalogCategory??"Approved",sourceAuthority:icon.rasterMasterSource?"certified-master":"approved-icon"}}))],
          }]:[]),
          ...(capabilities.plugSide==="authorable"&&plugActive&&!capabilities.plugOptional?[{
            id:"plug-side",label:"Plug side",type:"segmented" as const,value:active.plugSide??capabilities.allowedPlugSides?.[0]??"left",commandId:CURATED_AUTHORING_COMMANDS.updateAction,
            options:(capabilities.allowedPlugSides??["left","right"]).map((id)=>({id,label:id[0].toUpperCase()+id.slice(1),availability:"enabled" as const})),
          }]:[]),
        ] : [],
      },
    ],
    commandIds: Object.values(CURATED_AUTHORING_COMMANDS),
    previewAuthority: "SignatureMasterBridge/canonical-composition-renderer",
    persistenceAuthority: "signatureAssemblyAuthoring@1.0.0",
    historyAuthority: "CardBuilder labeled undo/redo",
    entitlementKeys: [],
    tapItCommandIds: [CURATED_AUTHORING_COMMANDS.updateAction, CURATED_AUTHORING_COMMANDS.reorderAction],
    capabilityDeclarations: declarations,
  };
  return assertStudioAuthoringCompleteness(declarations, contract);
}

function characterLimitAt(precision: NonNullable<StudioStructuredAssemblyDescriptor["textPrecision"]>, px: number) {
  if (px <= precision.defaultPx) {
    const span = Math.max(.001, precision.defaultPx - precision.minPx);
    const progress = (px - precision.minPx) / span;
    return Math.floor(precision.characterLimits.atMin + (precision.characterLimits.atDefault - precision.characterLimits.atMin) * progress);
  }
  const span = Math.max(.001, precision.maxPx - precision.defaultPx);
  const progress = (px - precision.defaultPx) / span;
  return Math.floor(precision.characterLimits.atDefault + (precision.characterLimits.atMax - precision.characterLimits.atDefault) * progress);
}

function safeMaxForLabel(precision: NonNullable<StudioStructuredAssemblyDescriptor["textPrecision"]>, length: number) {
  for (let px = precision.maxPx; px >= precision.minPx; px -= precision.stepPx) {
    if (length <= characterLimitAt(precision, px)) return Math.round(px * 100) / 100;
  }
  return precision.minPx;
}

export function curatedCommandPayloadToMutation(
  commandId: string,
  payload: unknown,
  assembly?: StudioStructuredAssemblyDescriptor,
): StudioCuratedAssemblyMutation | null {
  if (!payload || typeof payload !== "object") return null;
  if (commandId === CURATED_AUTHORING_COMMANDS.setLayout) {
    const presentationId = "presentationId" in payload ? payload.presentationId : "value" in payload ? payload.value : undefined;
    if (typeof presentationId === "string" && assembly?.layouts.some((layout)=>layout.id===presentationId)) return { type: "set-presentation", presentationId };
    const legacyLayoutMode="layoutMode" in payload?payload.layoutMode:undefined;
    if (legacyLayoutMode==="standalone"||legacyLayoutMode==="single-stack"||legacyLayoutMode==="twin-rail") {
      const registered=assembly?.layouts.find((layout)=>(layout.layoutMode??layout.id)===legacyLayoutMode);
      return registered?{type:"set-presentation",presentationId:registered.id}:{type:"set-layout",layoutMode:legacyLayoutMode};
    }
  }
  if (commandId === CURATED_AUTHORING_COMMANDS.setCount) {
    const count = "count" in payload ? payload.count : "value" in payload ? payload.value : undefined;
    if (typeof count === "number") return { type: "set-action-count", count };
  }
  if (commandId === CURATED_AUTHORING_COMMANDS.setResourceSlot) {
    if (!("slotId" in payload) || typeof payload.slotId !== "string") return null;
    if (!(assembly?.resourceSlots ?? []).some((slot) => slot.id === payload.slotId && slot.applicable)) return null;
    if (!("resource" in payload) || payload.resource == null) return { type: "set-resource-slot", slotId: payload.slotId };
    if (typeof payload.resource !== "object" || !("src" in payload.resource) || typeof payload.resource.src !== "string" || !("alt" in payload.resource) || typeof payload.resource.alt !== "string" || !("provenance" in payload.resource) || typeof payload.resource.provenance !== "string") return null;
    return { type: "set-resource-slot", slotId: payload.slotId, resource: payload.resource as StudioSemanticResource };
  }
  if (commandId === CURATED_AUTHORING_COMMANDS.setAppearance) {
    if (!("roleId" in payload) || typeof payload.roleId !== "string" || !("value" in payload) || typeof payload.value !== "string") return null;
    const role = assembly?.appearance.roles.find((candidate) => candidate.id === payload.roleId);
    const option = role?.options.find((candidate) => candidate.id === payload.value && candidate.availability === "enabled");
    return role && option ? { type: "set-appearance-option", roleId: role.id, optionId: option.id } : null;
  }
  if (commandId === CURATED_AUTHORING_COMMANDS.reorderAction && "from" in payload && "to" in payload && typeof payload.from === "number" && typeof payload.to === "number") return { type: "reorder-action", from: payload.from, to: payload.to };
  if (commandId === CURATED_AUTHORING_COMMANDS.updateAction && "actionId" in payload && typeof payload.actionId === "string") {
    if ("patch" in payload && payload.patch && typeof payload.patch === "object") return { type: "update-action", actionId: payload.actionId, patch: payload.patch } as StudioCuratedAssemblyMutation;
    if (!("controlId" in payload) || !("value" in payload) || typeof payload.controlId !== "string") return null;
    if (payload.controlId === "text-size" && typeof payload.value === "number") {
      return { type: "update-action", actionId: payload.actionId, patch: { textSizePx: payload.value } };
    }
    if (payload.controlId === "background-reflection" && typeof payload.value === "number" && assembly?.capabilities?.supportsBackgroundReflection) {
      return { type: "update-action", actionId: payload.actionId, patch: { backgroundReflectionIntensity: payload.value } };
    }
    if (typeof payload.value !== "string") return null;
    const slot = assembly?.slots.find((candidate) => candidate.id === payload.actionId);
    if (payload.controlId.startsWith("action-appearance:")) {
      const roleId = payload.controlId.slice("action-appearance:".length);
      const role = assembly?.appearance.roles.find((candidate) => candidate.id === roleId && !candidate.governed);
      if (!role) return null;
      const current = { ...(slot?.appearanceOptionIds ?? {}) };
      if (payload.value === "__inherit__") delete current[roleId];
      else if (!role.options.some((option) => option.id === payload.value && option.availability === "enabled")) return null;
      else current[roleId] = payload.value;
      return { type: "update-action", actionId: payload.actionId, patch: { appearanceOptionIds: Object.keys(current).length ? current : undefined } };
    }
    const patch = payload.controlId === "label" ? { label: payload.value }
      : payload.controlId === "sublabel" && assembly?.capabilities?.supportsSublabel ? { sublabel: payload.value }
      : payload.controlId === "accessible-name" ? { accessibilityLabel: payload.value }
      : payload.controlId === "semantic-label" && assembly?.capabilities?.supportsSemanticIcon ? { semanticLabel: payload.value }
      : payload.controlId === "action-intent" ? actionIntentPatch(payload.value, slot?.destination)
          : payload.controlId === "destination" ? destinationPatch(slot?.actionType, payload.value)
            : payload.controlId === "alignment" && ["left", "center", "right"].includes(payload.value) ? { textAlign: payload.value as "left" | "center" | "right" }
              : payload.controlId === "text-size" && ["small", "medium", "large"].includes(payload.value) ? { textSize: payload.value as "small" | "medium" | "large" }
                : payload.controlId === "plug-mode" && assembly?.capabilities?.plugOptional
                  ? payload.value==="body-only" ? {plugEnabled:false}
                    : payload.value==="left"||payload.value==="right" ? {plugEnabled:true,plugSide:payload.value as "left"|"right"}
                      : payload.value==="plug" ? {plugEnabled:true}
                        : null
                : payload.controlId === "plug" || payload.controlId === "plug-presentation" ? assembly?.capabilities?.supportsSemanticIcon ? { plugPresentationId: payload.value } : { plugComponentId: payload.value }
                  : payload.controlId === "semantic-icon" && assembly?.capabilities?.supportsSemanticIcon ? { semanticIconRef: payload.value === "__blank__" ? undefined : assembly.compatibleSemanticIcons?.find((icon)=>icon.canonicalId===payload.value) }
                    : payload.controlId === "plug-side" && assembly?.capabilities?.plugSide==="authorable" && (payload.value==="left"||payload.value==="right") ? { plugSide:payload.value as "left"|"right" }
                  : null;
    return patch ? { type: "update-action", actionId: payload.actionId, patch } : null;
  }
  return null;
}

function destinationPatch(actionType: string | undefined, destination: string) {
  const kind = standardButtonActions().some((action) => action.kind === actionType) ? actionType as StandardButtonActionIntent : "website";
  const reconciled = reconcileActionIntent(kind, destination);
  const props = actionProps(reconciled.kind, reconciled.destination);
  return { actionType: String(props.actionType), destination: reconciled.kind === "internal_page" ? reconciled.destination : String(props.href) };
}

function actionIntentPatch(actionType: string, currentDestination?: string) {
  const kind = standardButtonActions().some((action) => action.kind === actionType) ? actionType as StandardButtonActionIntent : "website";
  if (currentDestination && !validateActionDestination(kind, currentDestination)) {
    const props = actionProps(kind, currentDestination);
    return { actionType: String(props.actionType), destination: kind === "internal_page" ? currentDestination : String(props.href) };
  }
  const destination = kind === "call" ? "tel:"
    : kind === "sms" ? "sms:"
      : kind === "email" ? "mailto:"
        : kind === "map" ? "geo:"
          : kind === "internal_page" ? ""
            : "https://";
  return { actionType: kind, destination };
}
